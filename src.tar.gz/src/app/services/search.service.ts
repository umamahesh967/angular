import { Injectable } from '@angular/core';
import {Http,Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()

export class SearchService{

    private query : string;
    private API_URL : string= 'https://maps.googleapis.com/maps/api/place/textsearch/json?query=';
    private API_KEY : string= 'AIzaSyAiMSeDQ3c9MS-oVjfr3ihSv0a14g3jOT8';
    private URL : string=this.API_URL;
    private PER_PAGE:string="&per_page=10";

    constructor(private _http : Http){}

    getImages(query){
        return this._http.get(this.URL+query+'&key='+this.API_KEY+this.PER_PAGE).map(result => result.json());
    }



}